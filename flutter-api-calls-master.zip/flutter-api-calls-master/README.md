# flutter_api_calls

Flutter application to demonstrate api calls. A very basic example.
The blog post for this repository can be found here: https://ayusch.com/how-to-make-an-api-call-in-flutter-rest-api/

